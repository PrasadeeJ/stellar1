/*
 package stellar;
 

import org.stellar.sdk.KeyPair;
import org.stellar.sdk.Server;
import org.stellar.sdk.responses.AccountResponse;

import java.net.*;
import java.io.*;
import java.util.*;


public class main {

	
		public static void main(String[] args) throws Exception {
		

				KeyPair pair = KeyPair.random();

				System.out.println("secret seed " + new String(pair.getSecretSeed()));
				System.out.println("account id " + pair.getAccountId());
				
							
				String friendbotUrl = String.format(
				  "https://friendbot.stellar.org/?addr=%s",
				  pair.getAccountId());
				InputStream response = new URL(friendbotUrl).openStream();
				String body = new Scanner(response, "UTF-8").useDelimiter("\\A").next();
				System.out.println("SUCCESS! You have a new account :)\n" + body);
				
			

		Server server = new Server("https://horizon-testnet.stellar.org");
		AccountResponse account = server.accounts().account(pair);
		System.out.println("Balances for account " + pair.getAccountId());
		for (AccountResponse.Balance balance : account.getBalances()) {
		  System.out.println(String.format(
		    "Type: %s, Code: %s, Balance: %s",
		    balance.getAssetType(),
		    balance.getAssetCode(),
		    balance.getBalance()));
		}
		
	}
}
*/

package stellar;

import java.io.IOException;

import org.stellar.sdk.AssetTypeNative;
import org.stellar.sdk.KeyPair;
import org.stellar.sdk.ManageDataOperation;
import org.stellar.sdk.Memo;
import org.stellar.sdk.Network;
import org.stellar.sdk.PaymentOperation;
import org.stellar.sdk.Server;
import org.stellar.sdk.Transaction;
import org.stellar.sdk.responses.AccountResponse;
import org.stellar.sdk.responses.SubmitTransactionResponse;

public class main {

	
		public static void main(String[] args){
		
			Network.useTestNetwork();
			Server server = new Server("https://horizon-testnet.stellar.org");

			KeyPair source = KeyPair.fromSecretSeed("SDJWX6XLDISISJKKHZM7CYZFUZHYQCKATZUVBBMAMK7XZNIM27YKSEFO");
			KeyPair destination = KeyPair.fromAccountId("GAB75EMJ37LNFHDONCLWLX5LKFZ4FXN7XEFWUMCX6BHXLVDWWNN3OV3W");

			// First, check to make sure that the destination account exists.
			// You could skip this, but if the account does not exist, you will be charged
			// the transaction fee when the transaction fails.
			// It will throw HttpResponseException if account does not exist or there was another error.
			try {
				server.accounts().account(destination);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			// If there was no error, load up-to-date information on your account.
			AccountResponse sourceAccount = null;
			try {
				sourceAccount = server.accounts().account(source);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			
		//	Transaction transaction = new Transaction.Builder(sourceAccount).addOperation( new ManageDataOperation.Builder()).build());
			Transaction transaction1 = new Transaction.Builder(sourceAccount).addOperation(new ManageDataOperation.Builder(String name byte[] value).build()).addMemo(Memo.text("99XT Blockchain Lab")).build();
			// Start building the transaction.
			/* to send lumens
			Transaction transaction = new Transaction.Builder(sourceAccount)
			        .addOperation(new PaymentOperation.Builder(destination, new AssetTypeNative(), "2").build())
			        // A memo allows you to add your own metadata to a transaction. It's
			        // optional and does not affect how Stellar treats the transaction.
			        .addMemo(Memo.text("acc 4 to acc 3"))
			        .build();
			        */
			// Sign the transaction to prove you are actually the person sending it.
			transaction1.sign(source);

			// And finally, send it off to Stellar!
			try {
			 SubmitTransactionResponse response = server.submitTransaction(transaction1);
			  System.out.println("Success!");
			  System.out.println(response);
			} catch (Exception e) {
			  System.out.println("Something went wrong!");
			  System.out.println(e.getMessage());
			  // If the result is unknown (no response body, timeout etc.) we simply resubmit
			  // already built transaction:
			   SubmitTransactionResponse response = server.submitTransaction(transaction1);
			}
				
			 byte[] alue={1,2,3};
			 ManageDataOperation.Builder buildsq= new ManageDataOperation.Builder("first_data",alue);
			    // ManageDataOperation.Builder(null,null);
			 //ManageDataOperationResponse here= new ManageDataOperationResponse("first data", null);


			}

		
	}

